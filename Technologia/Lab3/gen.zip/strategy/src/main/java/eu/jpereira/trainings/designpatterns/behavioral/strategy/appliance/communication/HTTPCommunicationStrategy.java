/**
 * Copyright 2011 Joao Miguel Pereira
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package eu.jpereira.trainings.designpatterns.behavioral.strategy.appliance.communication;

/**
 * @author jpereira
 *
 */
public class HTTPCommunicationStrategy implements CommunicationStrategy {

	/* (non-Javadoc)
	 * @see eu.jpereira.trainings.designpatterns.behavioral.strategy.appliance.communication.CommunicationStrategy#connect(eu.jpereira.trainings.designpatterns.behavioral.strategy.appliance.communication.ConnectionProperties)
	 */
	@Override
	public void connect(ConnectionProperties properties) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eu.jpereira.trainings.designpatterns.behavioral.strategy.appliance.communication.CommunicationStrategy#sendRequest(eu.jpereira.trainings.designpatterns.behavioral.strategy.appliance.communication.Request)
	 */
	@Override
	public void sendRequest(Request request) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see eu.jpereira.trainings.designpatterns.behavioral.strategy.appliance.communication.CommunicationStrategy#disconnect()
	 */
	@Override
	public void disconnect() {
		// TODO Auto-generated method stub

	}

}
